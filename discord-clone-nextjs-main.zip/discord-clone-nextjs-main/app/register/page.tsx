import { useEffect } from 'react';

export default function Home() {
  useEffect(() => {}, []);

  return (
    <div>
      <h1>Register</h1>
    </div>
  );
}
